# Pentest Docker Suite (Full)

Professional Red Team / Pentest Docker environment.

## Containers
- recon-box: nmap, nuclei, amass, ffuf, masscan, osmedeus
- exploitation-box: metasploit + postgresql
- spiderfoot: OSINT framework
- gvm: OpenVAS (external image)

## Run
docker compose up -d --build
